World of Goo uses the following third-party libraries in accordance with their
respective open-source licenses:

- zlib
  by Jean-loup Gailly and Mark Adler
  http://www.zlib.net/

- libpng
  by Guy Eric Schalnat, Andreas Dilger, Glenn Randers-Pehrson and others
  http://www.libpng.org/pub/png/libpng.html

- Open Dynamics Engine (ODE)
  by Russell Smith
  http://www.ode.org/

- Simple DirectMedia Layer (SDL)
  By the SDL Project
  http://www.libsdl.org/
  See COPYING-SDL for license details

- SDL_mixer
  by Sam Lantinga, Stephane Peter and Ryan Gordon
  http://www.libsdl.org/projects/SDL_mixer/
  See COPYING-SDL for license details

- Ogg Vorbis (libogg, libvorbis, vorbisfile)
  Xiph.org Foundation
  http://xiph.org/vorbis/
  See COPYING-ogg-vorbis for license details

- libcurl
  By Daniel Stenberg and others
  http://curl.haxx.se/libcurl/

- OpenSSL (libopenssl, libcrypto)
  Developed by the OpenSSL Project for use in the OpenSSL Toolkit
  http://www.openssl.org/

- ManyMouse
  By Ryan C. Gordon
  http://icculus.org/manymouse/

